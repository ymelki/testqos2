<?php

namespace Deployer\Component\Version\Exception;

use Exception;

/**
 * The base library exception class.
 *
 * @author Kevin Herrera <kevin@herrera.io>
 */
class VersionException extends Exception
{
}
