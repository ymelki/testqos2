<?php

namespace Deployer\Component\PHPUnit\Exception;

/**
 * The interface is used to indicate the library responsible for the exception.
 *
 * @author Kevin Herrera <kevin@herrera.io>
 */
interface ExceptionInterface
{
}