<?php
require __DIR__ . '/../vendor/autoload.php';

org\bovigo\vfs\vfsStreamWrapper::register();
