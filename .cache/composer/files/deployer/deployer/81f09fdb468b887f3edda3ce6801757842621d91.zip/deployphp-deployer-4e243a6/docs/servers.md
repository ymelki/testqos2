# Servers

Servers was renamed to [hosts](hosts.md) in Deployer 5.x.  
If you are looking for documentation to Deployer 4.x follow [this link](https://github.com/deployphp/docs/tree/4.x).
