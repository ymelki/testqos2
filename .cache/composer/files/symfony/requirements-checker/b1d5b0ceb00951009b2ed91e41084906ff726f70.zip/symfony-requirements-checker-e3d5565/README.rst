Symfony Requirements Checker
============================

Checks requirements for running Symfony and gives useful recommendations to
optimize PHP for Symfony.
